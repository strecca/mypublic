const API_BASE = process.env.ADMIN_API_URL || 'http://localhost:3000/api';

class APIError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'APIError';
  }
}

async function apiRequest<T>(
  endpoint: string, 
  options: RequestInit = {}
): Promise<T> {
  const url = `${API_BASE}${endpoint}`;
  const config: RequestInit = {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  };

  // Add auth token if available (from session/localStorage)
  const token = localStorage.getItem('auth_token');
  if (token) {
    config.headers = {
      ...config.headers,
      'Authorization': `Bearer ${token}`,
    };
  }

  try {
    const response = await fetch(url, config);
    
    if (!response.ok) {
      throw new APIError(response.status, `API Error: ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    if (error instanceof APIError) throw error;
    throw new APIError(0, 'Network error or server unavailable');
  }
}

// Authentication
export async function loginUser(email: string, password: string) {
  return apiRequest<{ user: any; token: string }>('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
}

export async function refreshToken() {
  return apiRequest<{ token: string }>('/auth/refresh', {
    method: 'POST',
  });
}

// Forms
export async function getAssignedForms(userGroups: string[]) {
  const groupsParam = userGroups.join(',');
  return apiRequest<FormSchema[]>(`/forms/assigned?groups=${groupsParam}`);
}

export async function getFormById(formId: string) {
  return apiRequest<FormSchema>(`/forms/${formId}`);
}

// Submissions
export async function submitForm(formId: string, data: any, metadata: any) {
  return apiRequest<{ id: string; status: string }>('/submissions', {
    method: 'POST',
    body: JSON.stringify({
      formId,
      data,
      metadata,
      submittedAt: new Date().toISOString(),
    }),
  });
}

export async function getUserSubmissions(limit: number = 20) {
  return apiRequest<FormSubmission[]>(`/submissions/user?limit=${limit}`);
}

export async function getSubmissionStatus(submissionId: string) {
  return apiRequest<{ status: string; syncedAt?: string }>(`/submissions/${submissionId}/status`);
}

// Sync operations
export async function syncPendingSubmissions(submissions: any[]) {
  return apiRequest<{ synced: number; errors: any[] }>('/sync/submissions', {
    method: 'POST',
    body: JSON.stringify({ submissions }),
  });
}

// Notifications
export async function subscribeToNotifications(subscription: any) {
  return apiRequest<{ success: boolean }>('/notifications/subscribe', {
    method: 'POST',
    body: JSON.stringify({ subscription }),
  });
}

export { APIError };
