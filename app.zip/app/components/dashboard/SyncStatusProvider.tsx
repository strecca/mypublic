import React, { createContext, useContext, useState, useEffect } from 'react';
import type { SyncStatus } from '~/types';

const SyncStatusContext = createContext<SyncStatus>({
  isOnline: true,
  lastSync: new Date(),
  pendingSubmissions: 0,
  syncInProgress: false,
  errors: [],
});

export function useSyncStatus() {
  return useContext(SyncStatusContext);
}

interface SyncStatusProviderProps {
  children: React.ReactNode;
}

export function SyncStatusProvider({ children }: SyncStatusProviderProps) {
  const [status, setStatus] = useState<SyncStatus>({
    isOnline: true,
    lastSync: new Date(),
    pendingSubmissions: 0,
    syncInProgress: false,
    errors: [],
  });

  useEffect(() => {
    // Monitor online/offline status
    const updateOnlineStatus = () => {
      setStatus(prev => ({ ...prev, isOnline: navigator.onLine }));
    };

    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);

    // Check initial status
    updateOnlineStatus();

    // Periodic sync check
    const syncInterval = setInterval(() => {
      // In production, this would check the sync queue and attempt sync
      if (navigator.onLine && !status.syncInProgress) {
        // Simulated sync logic
        setStatus(prev => ({ ...prev, lastSync: new Date() }));
      }
    }, 30000); // Check every 30 seconds

    return () => {
      window.removeEventListener('online', updateOnlineStatus);
      window.removeEventListener('offline', updateOnlineStatus);
      clearInterval(syncInterval);
    };
  }, [status.syncInProgress]);

  return (
    <SyncStatusContext.Provider value={status}>
      {children}
    </SyncStatusContext.Provider>
  );
}
