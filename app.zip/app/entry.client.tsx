import { HydratedRouter } from 'react-router/dom';
import { startTransition, StrictMode } from 'react';
import { hydrateRoot } from 'react-dom/client';
import { initDB } from './utils/offline-db';

// Initialize offline database
initDB().then(() => {
  console.log('✅ Offline database initialized');
}).catch(console.error);

startTransition(() => {
  hydrateRoot(
    document,
    <StrictMode>
      <HydratedRouter />
    </StrictMode>
  );
});
