export interface User {
  id: string;
  email: string;
  name: string;
  groups: string[];
  permissions: string[];
  role: 'user' | 'moderator';
  avatar?: string;
  lastLogin?: Date;
}

export interface FormSchema {
  id: string;
  name: string;
  description: string;
  version: number;
  schema: any; // JSON schema
  styling: FormStyling;
  settings: FormSettings;
  assignedGroups: string[];
  createdAt: Date;
  updatedAt: Date;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  dueDate?: Date;
  status: 'draft' | 'active' | 'archived';
}

export interface FormStyling {
  colorCode: string;
  theme: 'light' | 'dark' | 'auto';
  customCSS?: string;
  layout: 'single-column' | 'two-column' | 'tabbed';
}

export interface FormSettings {
  allowDrafts: boolean;
  autoSave: boolean;
  requiredFields: string[];
  validationRules: Record<string, any>;
  maxSubmissions?: number;
  deadline?: Date;
}

export interface FormSubmission {
  id: string;
  formId: string;
  userId: string;
  data: Record<string, any>;
  status: 'draft' | 'submitted' | 'synced' | 'error';
  version: number;
  createdAt: Date;
  updatedAt: Date;
  submittedAt?: Date;
  syncedAt?: Date;
  metadata: {
    deviceInfo: string;
    location?: GeolocationPosition;
    timeSpent: number;
    revisionsCount: number;
  };
}

export interface NotificationPayload {
  type: 'new_form' | 'form_update' | 'deadline_reminder' | 'sync_complete';
  title: string;
  message: string;
  data?: Record<string, any>;
  priority: 'low' | 'normal' | 'high';
}

export interface SyncStatus {
  isOnline: boolean;
  lastSync: Date;
  pendingSubmissions: number;
  syncInProgress: boolean;
  errors: string[];
}
