import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";

export async function loader() {
  return json({ 
    message: "Welcome to User PWA",
    timestamp: new Date().toISOString()
  });
}

export default function Index() {
  const { message } = useLoaderData<typeof loader>();
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">{message}</h1>
        <p className="text-gray-600 mb-6">Your Progressive Web App is ready!</p>
        <div className="space-y-4">
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-sm text-green-800">✅ PWA Features Enabled</p>
          </div>
        </div>
      </div>
    </div>
  );
}
