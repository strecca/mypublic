#!/bin/bash
echo "🚀 Starting User PWA..."

# Check if admin backend is running
if ! curl -s http://localhost:3000/ > /dev/null 2>&1; then
    echo "⚠️  Warning: Admin backend not detected on port 3000"
    echo "   Some features may not work without the admin backend"
fi

echo "📱 Starting User PWA on port 3001..."
npm run dev
