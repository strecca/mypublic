# Continue creating the User PWA components and routes

echo "📱 Creating User PWA Components and Routes..."

# Create root component with PWA support
cat > app/root.tsx << 'EOF'
import {
  Links,
  LiveReload,
  Meta,
  Outlet,
  Scripts,
  ScrollRestoration,
  useLoaderData,
} from '@remix-run/react';
import type { LinksFunction, LoaderFunctionArgs } from '@remix-run/node';
import { json } from '@remix-run/node';
import tailwindStyles from './tailwind.css';
import { Toaster } from 'react-hot-toast';
import { useEffect } from 'react';

export const links: LinksFunction = () => [
  { rel: 'stylesheet', href: tailwindStyles },
  { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
  { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
  { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap' },
  { rel: 'manifest', href: '/manifest.json' },
  { rel: 'apple-touch-icon', sizes: '180x180', href: '/icons/apple-touch-icon.png' },
];

export async function loader({ request }: LoaderFunctionArgs) {
  return json({
    ENV: {
      ENABLE_OFFLINE_MODE: process.env.ENABLE_OFFLINE_MODE === 'true',
      ENABLE_PUSH_NOTIFICATIONS: process.env.ENABLE_PUSH_NOTIFICATIONS === 'true',
    }
  });
}

export default function App() {
  const { ENV } = useLoaderData<typeof loader>();

  useEffect(() => {
    // Initialize PWA features
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(console.error);
    }
  }, []);

  return (
    <html lang="en" className="h-full">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
        <meta name="theme-color" content="#3b82f6" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <Meta />
        <Links />
      </head>
      <body className="h-full bg-gray-50 font-sans antialiased">
        <Outlet />
        <Toaster 
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#363636',
              color: '#fff',
            },
          }}
        />
        <ScrollRestoration />
        <Scripts />
        <script
          dangerouslySetInnerHTML={{
            __html: `window.ENV = ${JSON.stringify(ENV)}`,
          }}
        />
        <LiveReload />
      </body>
    </html>
  );
}
EOF

# Create main entry files
cat > app/entry.client.tsx << 'EOF'
import { RemixBrowser } from '@remix-run/react';
import { startTransition, StrictMode } from 'react';
import { hydrateRoot } from 'react-dom/client';
import { initDB } from './utils/offline-db';

// Initialize offline database
initDB().then(() => {
  console.log('✅ Offline database initialized');
}).catch(console.error);

startTransition(() => {
  hydrateRoot(
    document,
    <StrictMode>
      <RemixBrowser />
    </StrictMode>
  );
});
EOF

cat > app/entry.server.tsx << 'EOF'
import type { EntryContext } from '@remix-run/node';
import { Response } from '@remix-run/node';
import { RemixServer } from '@remix-run/react';
import { renderToString } from 'react-dom/server';

export default function handleRequest(
  request: Request,
  responseStatusCode: number,
  responseHeaders: Headers,
  remixContext: EntryContext
) {
  const markup = renderToString(
    <RemixServer context={remixContext} url={request.url} />
  );

  responseHeaders.set('Content-Type', 'text/html');

  return new Response('<!DOCTYPE html>' + markup, {
    status: responseStatusCode,
    headers: responseHeaders,
  });
}
EOF

# Create Tailwind CSS with custom utilities
cat > app/tailwind.css << 'EOF'
@tailwind base;
@tailwind components;
@tailwind utilities;

@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

@layer base {
  html {
    font-family: 'Inter', system-ui, sans-serif;
  }
}

@layer components {
  .form-card {
    @apply bg-white rounded-xl shadow-sm border border-gray-200 p-6 transition-all duration-200 hover:shadow-md hover:border-gray-300;
  }
  
  .form-card-urgent {
    @apply border-l-4 border-l-red-500 bg-red-50;
  }
  
  .form-card-high {
    @apply border-l-4 border-l-orange-500 bg-orange-50;
  }
  
  .form-card-medium {
    @apply border-l-4 border-l-blue-500 bg-blue-50;
  }
  
  .form-card-low {
    @apply border-l-4 border-l-green-500 bg-green-50;
  }

  .status-badge {
    @apply inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium;
  }
  
  .status-synced {
    @apply status-badge bg-green-100 text-green-800;
  }
  
  .status-pending {
    @apply status-badge bg-yellow-100 text-yellow-800;
  }
  
  .status-draft {
    @apply status-badge bg-gray-100 text-gray-800;
  }
  
  .status-error {
    @apply status-badge bg-red-100 text-red-800;
  }

  .btn-primary {
    @apply inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors;
  }
  
  .btn-secondary {
    @apply inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors;
  }
}

@layer utilities {
  .safe-area-inset {
    padding-left: env(safe-area-inset-left);
    padding-right: env(safe-area-inset-right);
  }
  
  .safe-area-inset-top {
    padding-top: env(safe-area-inset-top);
  }
  
  .safe-area-inset-bottom {
    padding-bottom: env(safe-area-inset-bottom);
  }
}

/* Custom scrollbar for webkit browsers */
::-webkit-scrollbar {
  width: 6px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 3px;
}

::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
  background: #a8a8a8;
}

/* Loading animation */
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.animate-spin {
  animation: spin 1s linear infinite;
}

/* Pulse animation for loading states */
@keyframes pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
}

.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
EOF

# Create user authentication routes
cat > app/routes/_index.tsx << 'EOF'
import { redirect } from '@remix-run/node';

export const loader = () => {
  return redirect('/dashboard');
};
EOF

# Create user session utilities
cat > app/utils/user-session.server.ts << 'EOF'
import { createCookieSessionStorage, redirect } from '@remix-run/node';

const sessionSecret = process.env.SESSION_SECRET || 'user-session-secret';

const storage = createCookieSessionStorage({
  cookie: {
    name: 'user-session', 
    secure: process.env.NODE_ENV === 'production',
    secrets: [sessionSecret],
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 30, // 30 days
    httpOnly: true,
  },
});

export async function createUserSession(userId: string, redirectTo: string) {
  const session = await storage.getSession();
  session.set('userId', userId);
  return redirect(redirectTo, {
    headers: {
      'Set-Cookie': await storage.commitSession(session),
    },
  });
}

export async function getUserSession(request: Request) {
  return storage.getSession(request.headers.get('Cookie'));
}

export async function getUserId(request: Request) {
  const session = await getUserSession(request);
  const userId = session.get('userId');
  if (!userId || typeof userId !== 'string') return null;
  return userId;
}

export async function requireUserId(request: Request, redirectTo: string = '/login') {
  const userId = await getUserId(request);
  if (!userId) {
    throw redirect(redirectTo);
  }
  return userId;
}

export async function logout(request: Request) {
  const session = await getUserSession(request);
  return redirect('/login', {
    headers: {
      'Set-Cookie': await storage.destroySession(session),
    },
  });
}
EOF

# Create login route
cat > app/routes/login.tsx << 'EOF'
import { ActionFunctionArgs, LoaderFunctionArgs, json, redirect } from '@remix-run/node';
import { Form, Link, useActionData, useNavigation } from '@remix-run/react';
import { useState } from 'react';
import { Eye, EyeOff, Smartphone, Shield, Wifi } from 'lucide-react';
import { createUserSession, getUserId } from '~/utils/user-session.server';
import { loginUser } from '~/utils/api';

export async function loader({ request }: LoaderFunctionArgs) {
  const userId = await getUserId(request);
  if (userId) return redirect('/dashboard');
  return json({});
}

export async function action({ request }: ActionFunctionArgs) {
  const formData = await request.formData();
  const email = formData.get('email');
  const password = formData.get('password');

  if (typeof email !== 'string' || typeof password !== 'string') {
    return json({ error: 'Invalid form data' }, { status: 400 });
  }

  if (!email.includes('@')) {
    return json({ error: 'Please enter a valid email address' }, { status: 400 });
  }

  try {
    const { user, token } = await loginUser(email, password);
    
    // Store token for API requests
    // In production, you'd handle this more securely
    return json({ user, token, redirectTo: '/dashboard' });
  } catch (error: any) {
    return json({ 
      error: error.message || 'Login failed. Please check your credentials.' 
    }, { status: 400 });
  }
}

export default function Login() {
  const actionData = useActionData<typeof action>();
  const navigation = useNavigation();
  const [showPassword, setShowPassword] = useState(false);
  
  const isSubmitting = navigation.state === 'submitting';

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center px-4 safe-area-inset">
      <div className="max-w-md w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
            <Smartphone className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome Back
          </h2>
          <p className="text-gray-600">
            Sign in to access your forms
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="p-3">
            <Shield className="w-6 h-6 text-blue-600 mx-auto mb-2" />
            <p className="text-xs text-gray-600">Secure</p>
          </div>
          <div className="p-3">
            <Wifi className="w-6 h-6 text-green-600 mx-auto mb-2" />
            <p className="text-xs text-gray-600">Offline Ready</p>
          </div>
          <div className="p-3">
            <Smartphone className="w-6 h-6 text-purple-600 mx-auto mb-2" />
            <p className="text-xs text-gray-600">Mobile First</p>
          </div>
        </div>

        {/* Login Form */}
        <div className="bg-white py-8 px-6 shadow-xl rounded-2xl border border-gray-100">
          <Form method="post" className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                disabled={isSubmitting}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all disabled:opacity-50"
                placeholder="your.email@company.com"
              />
            </div>
            
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  required
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all disabled:opacity-50"
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                  disabled={isSubmitting}
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-gray-400" />
                  ) : (
                    <Eye className="h-5 w-5 text-gray-400" />
                  )}
                </button>
              </div>
            </div>

            {actionData?.error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-center">
                  <div className="w-4 h-4 bg-red-500 rounded-full mr-3"></div>
                  <p className="text-sm text-red-600">{actionData.error}</p>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full btn-primary py-3 text-base font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Signing In...
                </div>
              ) : (
                'Sign In'
              )}
            </button>
          </Form>

          {/* Demo credentials - remove in production */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h4 className="text-sm font-medium text-blue-800 mb-2">Demo Credentials</h4>
            <div className="text-sm text-blue-600 space-y-1">
              <p><strong>User:</strong> user@pharmacies-west.com</p>
              <p><strong>Password:</strong> user123</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center">
          <p className="text-sm text-gray-500">
            Need help? Contact your administrator
          </p>
        </div>
      </div>
    </div>
  );
}
EOF

# Create main dashboard route
cat > app/routes/dashboard.tsx << 'EOF'
import { LoaderFunctionArgs, json } from '@remix-run/node';
import { useLoaderData, Outlet, useLocation } from '@remix-run/react';
import { requireUserId } from '~/utils/user-session.server';
import { DashboardLayout } from '~/components/dashboard/DashboardLayout';
import { SyncStatusProvider } from '~/components/dashboard/SyncStatusProvider';

export async function loader({ request }: LoaderFunctionArgs) {
  const userId = await requireUserId(request);
  
  // In production, fetch user data from your admin backend
  const mockUser = {
    id: userId,
    name: 'John Doe',
    email: 'john@pharmacies-west.com',
    groups: ['Pharmacies West', 'Regional Managers'],
    avatar: null,
    permissions: ['read', 'write'],
    role: 'user' as const,
  };

  return json({ user: mockUser });
}

export default function Dashboard() {
  const { user } = useLoaderData<typeof loader>();
  const location = useLocation();
  
  // If we're at the base dashboard route, show the main dashboard
  const showMainDashboard = location.pathname === '/dashboard';

  return (
    <SyncStatusProvider>
      <DashboardLayout user={user}>
        {showMainDashboard ? (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">
                Welcome, {user.name}
              </h1>
              <p className="text-gray-600">
                You have access to forms for: {user.groups.join(', ')}
              </p>
            </div>
            
            {/* Quick stats or recent activity would go here */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Active Forms</h3>
                <p className="text-3xl font-bold text-blue-600">3</p>
                <p className="text-sm text-gray-500">Ready to complete</p>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Completed</h3>
                <p className="text-3xl font-bold text-green-600">12</p>
                <p className="text-sm text-gray-500">This month</p>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Pending Sync</h3>
                <p className="text-3xl font-bold text-orange-600">0</p>
                <p className="text-sm text-gray-500">All synced</p>
              </div>
            </div>
          </div>
        ) : (
          <Outlet />
        )}
      </DashboardLayout>
    </SyncStatusProvider>
  );
}
EOF

echo "✅ User PWA routes and authentication created"
echo "📱 Next: Creating dashboard components and form renderer"