echo "==> Listing all installed production and dev packages..."
npm ls --all > npm_full_tree.txt
npm ls --prod > npm_prod_tree.txt
npm ls --dev > npm_dev_tree.txt
echo "==> Lists saved as npm_full_tree.txt, npm_prod_tree.txt, npm_dev_tree.txt"