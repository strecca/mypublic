# Create dashboard components and form handling

echo "📱 Creating Dashboard Components..."

# Create dashboard layout component
cat > app/components/dashboard/DashboardLayout.tsx << 'EOF'
import { Link, useLocation, Form } from '@remix-run/react';
import { useState } from 'react';
import { 
  FileText, 
  Clock, 
  CheckCircle, 
  Settings, 
  LogOut, 
  Menu, 
  X,
  Wifi,
  WifiOff,
  RotateCcw
} from 'lucide-react';
import type { User } from '~/types';
import { useSyncStatus } from './SyncStatusProvider';

interface DashboardLayoutProps {
  user: User;
  children: React.ReactNode;
}

export function DashboardLayout({ user, children }: DashboardLayoutProps) {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { isOnline, syncInProgress, pendingSubmissions, lastSync } = useSyncStatus();

  const navigation = [
    { name: 'Active Forms', href: '/dashboard/forms', icon: FileText, count: 3 },
    { name: 'Drafts', href: '/dashboard/drafts', icon: Clock, count: 1 },
    { name: 'Completed', href: '/dashboard/completed', icon: CheckCircle, count: 12 },
    { name: 'Settings', href: '/dashboard/settings', icon: Settings },
  ];

  const isActive = (href: string) => location.pathname === href;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-gray-600 bg-opacity-75 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200">
            <h1 className="text-xl font-bold text-gray-900">FormApp</h1>
            <button
              onClick={() => setSidebarOpen(false)}
              className="p-2 rounded-md text-gray-400 hover:text-gray-600 lg:hidden"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* User info */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-medium">
                  {user.name.charAt(0).toUpperCase()}
                </span>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">{user.name}</p>
                <p className="text-xs text-gray-500">{user.groups[0]}</p>
              </div>
            </div>
          </div>

          {/* Sync status */}
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                {isOnline ? (
                  <Wifi className="w-4 h-4 text-green-500 mr-2" />
                ) : (
                  <WifiOff className="w-4 h-4 text-red-500 mr-2" />
                )}
                <span className="text-sm text-gray-600">
                  {isOnline ? 'Online' : 'Offline'}
                </span>
              </div>
              
              {syncInProgress && (
                <RotateCcw className="w-4 h-4 text-blue-500 animate-spin" />
              )}
            </div>
            
            {pendingSubmissions > 0 && (
              <p className="text-xs text-orange-600 mt-1">
                {pendingSubmissions} pending sync
              </p>
            )}
            
            {lastSync && (
              <p className="text-xs text-gray-500 mt-1">
                Last sync: {new Date(lastSync).toLocaleTimeString()}
              </p>
            )}
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-6 space-y-2">
            {navigation.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.href);
              
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => setSidebarOpen(false)}
                  className={`flex items-center justify-between px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                    active
                      ? 'bg-blue-100 text-blue-700 border-r-2 border-blue-500'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center">
                    <Icon className="w-5 h-5 mr-3" />
                    {item.name}
                  </div>
                  {item.count !== undefined && (
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      active 
                        ? 'bg-blue-200 text-blue-800' 
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {item.count}
                    </span>
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Logout */}
          <div className="p-4 border-t border-gray-200">
            <Form action="/logout" method="post">
              <button
                type="submit"
                className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4 mr-3" />
                Sign Out
              </button>
            </Form>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Top bar */}
        <div className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 py-4 safe-area-inset-top">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(true)}
              className="p-2 rounded-md text-gray-400 hover:text-gray-600 lg:hidden"
            >
              <Menu className="w-6 h-6" />
            </button>
            
            <div className="flex items-center space-x-4">
              {/* Sync indicator */}
              <div className="flex items-center">
                {syncInProgress ? (
                  <div className="flex items-center text-blue-600">
                    <RotateCcw className="w-4 h-4 animate-spin mr-1" />
                    <span className="text-sm">Syncing...</span>
                  </div>
                ) : isOnline ? (
                  <div className="flex items-center text-green-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <span className="text-sm">Connected</span>
                  </div>
                ) : (
                  <div className="flex items-center text-orange-600">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-2"></div>
                    <span className="text-sm">Offline</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <main className="p-6 safe-area-inset">
          {children}
        </main>
      </div>
    </div>
  );
}
EOF

# Create sync status provider
cat > app/components/dashboard/SyncStatusProvider.tsx << 'EOF'
import React, { createContext, useContext, useState, useEffect } from 'react';
import type { SyncStatus } from '~/types';

const SyncStatusContext = createContext<SyncStatus>({
  isOnline: true,
  lastSync: new Date(),
  pendingSubmissions: 0,
  syncInProgress: false,
  errors: [],
});

export function useSyncStatus() {
  return useContext(SyncStatusContext);
}

interface SyncStatusProviderProps {
  children: React.ReactNode;
}

export function SyncStatusProvider({ children }: SyncStatusProviderProps) {
  const [status, setStatus] = useState<SyncStatus>({
    isOnline: true,
    lastSync: new Date(),
    pendingSubmissions: 0,
    syncInProgress: false,
    errors: [],
  });

  useEffect(() => {
    // Monitor online/offline status
    const updateOnlineStatus = () => {
      setStatus(prev => ({ ...prev, isOnline: navigator.onLine }));
    };

    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);

    // Check initial status
    updateOnlineStatus();

    // Periodic sync check
    const syncInterval = setInterval(() => {
      // In production, this would check the sync queue and attempt sync
      if (navigator.onLine && !status.syncInProgress) {
        // Simulated sync logic
        setStatus(prev => ({ ...prev, lastSync: new Date() }));
      }
    }, 30000); // Check every 30 seconds

    return () => {
      window.removeEventListener('online', updateOnlineStatus);
      window.removeEventListener('offline', updateOnlineStatus);
      clearInterval(syncInterval);
    };
  }, [status.syncInProgress]);

  return (
    <SyncStatusContext.Provider value={status}>
      {children}
    </SyncStatusContext.Provider>
  );
}
EOF

# Create forms list route
cat > app/routes/dashboard.forms.tsx << 'EOF'
import { LoaderFunctionArgs, json } from '@remix-run/node';
import { useLoaderData, Link } from '@remix-run/react';
import { requireUserId } from '~/utils/user-session.server';
import { FormCard } from '~/components/forms/FormCard';
import { Clock, AlertCircle, Calendar, Plus } from 'lucide-react';
import type { FormSchema } from '~/types';

export async function loader({ request }: LoaderFunctionArgs) {
  await requireUserId(request);
  
  // In production, fetch from your admin backend API
  const mockForms: FormSchema[] = [
    {
      id: '1',
      name: 'Weekly Safety Inspection',
      description: 'Complete your weekly safety checklist for pharmacy operations',
      version: 1,
      schema: {
        title: 'Safety Inspection',
        type: 'object',
        properties: {
          inspector: { type: 'string', title: 'Inspector Name' },
          date: { type: 'string', format: 'date', title: 'Inspection Date' },
          emergencyExits: { type: 'boolean', title: 'Emergency exits clear?' },
          fireExtinguisher: { type: 'boolean', title: 'Fire extinguisher accessible?' },
          notes: { type: 'string', title: 'Additional Notes' }
        }
      },
      styling: {
        colorCode: '#dc2626',
        theme: 'light' as const,
        layout: 'single-column' as const
      },
      settings: {
        allowDrafts: true,
        autoSave: true,
        requiredFields: ['inspector', 'date'],
        validationRules: {}
      },
      assignedGroups: ['Pharmacies West'],
      createdAt: new Date('2024-01-15'),
      updatedAt: new Date('2024-01-15'),
      priority: 'urgent' as const,
      dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // Due in 2 days
      status: 'active' as const
    },
    {
      id: '2', 
      name: 'Monthly Inventory Report',
      description: 'Report on inventory levels and stock requirements',
      version: 2,
      schema: {
        title: 'Inventory Report',
        type: 'object',
        properties: {
          reporter: { type: 'string', title: 'Reporter Name' },
          month: { type: 'string', title: 'Report Month' },
          totalItems: { type: 'number', title: 'Total Items Counted' },
          lowStock: { type: 'array', title: 'Low Stock Items' },
          recommendations: { type: 'string', title: 'Recommendations' }
        }
      },
      styling: {
        colorCode: '#f59e0b',
        theme: 'light' as const,
        layout: 'two-column' as const
      },
      settings: {
        allowDrafts: true,
        autoSave: true,
        requiredFields: ['reporter', 'month', 'totalItems'],
        validationRules: {}
      },
      assignedGroups: ['Pharmacies West', 'Regional Managers'],
      createdAt: new Date('2024-01-10'),
      updatedAt: new Date('2024-01-12'),
      priority: 'high' as const,
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Due in 1 week
      status: 'active' as const
    },
    {
      id: '3',
      name: 'Customer Feedback Survey',
      description: 'Collect customer satisfaction feedback',
      version: 1,
      schema: {
        title: 'Customer Feedback',
        type: 'object',
        properties: {
          customerType: { type: 'string', enum: ['walk-in', 'regular', 'new'], title: 'Customer Type' },
          satisfaction: { type: 'number', minimum: 1, maximum: 5, title: 'Satisfaction Rating' },
          comments: { type: 'string', title: 'Comments' },
          wouldRecommend: { type: 'boolean', title: 'Would recommend to others?' }
        }
      },
      styling: {
        colorCode: '#3b82f6',
        theme: 'light' as const,
        layout: 'single-column' as const
      },
      settings: {
        allowDrafts: true,
        autoSave: false,
        requiredFields: ['customerType', 'satisfaction'],
        validationRules: {}
      },
      assignedGroups: ['Pharmacies West'],
      createdAt: new Date('2024-01-20'),
      updatedAt: new Date('2024-01-20'),
      priority: 'medium' as const,
      status: 'active' as const
    }
  ];

  return json({ forms: mockForms });
}

export default function FormsPage() {
  const { forms } = useLoaderData<typeof loader>();

  const urgentForms = forms.filter(f => f.priority === 'urgent');
  const otherForms = forms.filter(f => f.priority !== 'urgent');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Active Forms</h1>
          <p className="text-gray-600 mt-1">
            Complete your assigned forms below
          </p>
        </div>
      </div>

      {/* Urgent forms alert */}
      {urgentForms.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertCircle className="w-5 h-5 text-red-500 mr-3" />
            <div>
              <h3 className="text-sm font-medium text-red-800">
                Urgent Forms Require Attention
              </h3>
              <p className="text-sm text-red-600 mt-1">
                You have {urgentForms.length} urgent form{urgentForms.length === 1 ? '' : 's'} that need immediate completion.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Urgent forms section */}
      {urgentForms.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-red-700 flex items-center">
            <AlertCircle className="w-5 h-5 mr-2" />
            Urgent Forms
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {urgentForms.map((form) => (
              <FormCard key={form.id} form={form} />
            ))}
          </div>
        </div>
      )}

      {/* Other forms section */}
      {otherForms.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-gray-900">
            All Forms
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {otherForms.map((form) => (
              <FormCard key={form.id} form={form} />
            ))}
          </div>
        </div>
      )}

      {/* Empty state */}
      {forms.length === 0 && (
        <div className="text-center py-12">
          <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Active Forms</h3>
          <p className="text-gray-500 mb-6">
            You don't have any active forms assigned to your groups at the moment.
          </p>
          <div className="space-y-2 text-sm text-gray-400">
            <p>• New forms will appear here when assigned by your administrator</p>
            <p>• Forms are filtered based on your group membership</p>
            <p>• Check back regularly for new assignments</p>
          </div>
        </div>
      )}
    </div>
  );
}
EOF

# Create form card component
cat > app/components/forms/FormCard.tsx << 'EOF'
import { Link } from '@remix-run/react';
import { Calendar, Clock, AlertTriangle, FileText, Users } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import type { FormSchema } from '~/types';

interface FormCardProps {
  form: FormSchema;
}

export function FormCard({ form }: FormCardProps) {
  const getPriorityStyles = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'form-card-urgent border-red-500';
      case 'high':
        return 'form-card-high border-orange-500';
      case 'medium':
        return 'form-card-medium border-blue-500';
      case 'low':
        return 'form-card-low border-green-500';
      default:
        return 'form-card';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'high':
        return <Clock className="w-4 h-4 text-orange-500" />;
      default:
        return <FileText className="w-4 h-4 text-blue-500" />;
    }
  };

  const getPriorityBadge = (priority: string) => {
    const styles = {
      urgent: 'bg-red-100 text-red-800 border-red-200',
      high: 'bg-orange-100 text-orange-800 border-orange-200',
      medium: 'bg-blue-100 text-blue-800 border-blue-200',
      low: 'bg-green-100 text-green-800 border-green-200',
    };

    return (
      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${styles[priority as keyof typeof styles] || styles.medium}`}>
        {getPriorityIcon(priority)}
        <span className="ml-1 capitalize">{priority}</span>
      </span>
    );
  };

  const isOverdue = form.dueDate && new Date(form.dueDate) < new Date();
  const isDueSoon = form.dueDate && new Date(form.dueDate) < new Date(Date.now() + 24 * 60 * 60 * 1000);

  return (
    <Link
      to={`/dashboard/forms/${form.id}`}
      className={`block ${getPriorityStyles(form.priority)} hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200`}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 mb-1">
            {form.name}
          </h3>
          <p className="text-sm text-gray-600 line-clamp-2">
            {form.description}
          </p>
        </div>
        {getPriorityBadge(form.priority)}
      </div>

      {/* Due date warning */}
      {form.dueDate && (
        <div className={`mb-4 p-3 rounded-lg ${
          isOverdue 
            ? 'bg-red-50 border border-red-200' 
            : isDueSoon 
            ? 'bg-yellow-50 border border-yellow-200'
            : 'bg-gray-50 border border-gray-200'
        }`}>
          <div className="flex items-center">
            <Calendar className={`w-4 h-4 mr-2 ${
              isOverdue 
                ? 'text-red-500' 
                : isDueSoon 
                ? 'text-yellow-500'
                : 'text-gray-500'
            }`} />
            <span className={`text-sm font-medium ${
              isOverdue 
                ? 'text-red-700' 
                : isDueSoon 
                ? 'text-yellow-700'
                : 'text-gray-700'
            }`}>
              {isOverdue 
                ? 'Overdue' 
                : isDueSoon 
                ? 'Due today'
                : `Due ${formatDistanceToNow(new Date(form.dueDate), { addSuffix: true })}`
              }
            </span>
          </div>
        </div>
      )}

      {/* Form metadata */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center">
            <Users className="w-4 h-4 mr-1" />
            <span>{form.assignedGroups.join(', ')}</span>
          </div>
          <span>v{form.version}</span>
        </div>

        <div className="flex items-center text-sm text-gray-500">
          <Clock className="w-4 h-4 mr-1" />
          <span>Updated {formatDistanceToNow(new Date(form.updatedAt), { addSuffix: true })}</span>
        </div>
      </div>

      {/* Action indicator */}
      <div className="mt-4 pt-4 border-t border-gray-200">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-blue-600">
            Click to complete →
          </span>
          {form.settings.maxSubmissions && (
            <span className="text-xs text-gray-500">
              Max: {form.settings.maxSubmissions} submissions
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
EOF

echo "✅ Dashboard components created successfully"
echo "📱 Next: Creating form renderer and submission handling"