echo "==> Backing up package.json, package-lock.json, and node_modules..."
cp package.json package.json.bak
cp package-lock.json package-lock.json.bak 2>/dev/null
tar czf node_modules_backup.tgz node_modules
echo "==> Backups complete! You can always restore these if something goes wrong."