# Enterprise User PWA - Form Manager

A progressive web application for enterprise form management with offline-first capabilities.

## Features

🔐 **Secure Authentication** - Role-based access control
📱 **Progressive Web App** - Install on mobile devices
🔄 **Offline-First** - Work without internet connection
📋 **Dynamic Forms** - JSON schema-based form rendering
🎨 **Priority System** - Color-coded form urgency
💾 **Auto-Save** - Never lose your work
📊 **Progress Tracking** - Visual completion indicators
🔔 **Push Notifications** - Stay updated on new forms
📈 **Analytics** - Track form completion and usage

## Quick Start

1. **Setup development environment:**
   ```bash
   ./dev-setup.sh
   ```

2. **Start the User PWA:**
   ```bash
   npm run dev
   # or
   ./start-user-pwa.sh
   ```

3. **Access the application:**
   - URL: http://localhost:3001
   - Login with your credentials

## Enterprise Features

### Group-Based Access Control
- Forms filtered by user group membership
- Only see forms assigned to your groups
- Dynamic group management from admin backend

### Priority-Based Form Organization
- **Urgent** (Red): Critical forms requiring immediate attention
- **High** (Orange): Important forms with near deadlines
- **Medium** (Blue): Standard priority forms
- **Low** (Green): Optional or low-importance forms

### Offline Capabilities
- Forms cached locally using IndexedDB
- Continue working without internet
- Automatic sync when connection restored
- Draft auto-save every 2 seconds

### Advanced Form Features
- JSON schema-based dynamic rendering
- Custom validation rules
- Progress tracking and completion indicators
- Form versioning support
- Rich field types (text, select, date, checkbox, etc.)

## Configuration

### Environment Variables (.env)
```env
ADMIN_API_URL=http://localhost:3000/api
SESSION_SECRET=your-session-secret
ENABLE_OFFLINE_MODE=true
ENABLE_PUSH_NOTIFICATIONS=true
```

### PWA Settings
- Installable on mobile devices
- Offline caching with service workers
- Background sync for form submissions
- Push notifications for new forms

## API Integration

The User PWA connects to the Admin Backend API:

- **Authentication**: `/api/auth/login`
- **Forms**: `/api/forms/assigned?groups=...`
- **Submissions**: `/api/submissions`
- **Sync**: `/api/sync/submissions`

## Development

### Available Scripts
- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run typecheck` - Check TypeScript types

### Architecture
- **Frontend**: Remix + React + TypeScript
- **Styling**: Tailwind CSS with custom components
- **Storage**: IndexedDB for offline data
- **State**: React Hook Form + Zod validation
- **PWA**: Vite PWA plugin with Workbox

## Production Deployment

1. **Build the application:**
   ```bash
   npm run build
   ```

2. **Deploy to your hosting platform:**
   - Vercel, Netlify, or your preferred host
   - Ensure environment variables are configured
   - Set up HTTPS (required for PWA features)

## Troubleshooting

### Common Issues

**Forms not loading:**
- Check admin backend connectivity
- Verify user group assignments
- Check browser console for API errors

**Offline mode not working:**
- Ensure HTTPS (required for service workers)
- Check service worker registration
- Verify IndexedDB support

**Push notifications not working:**
- HTTPS required
- Check notification permissions
- Verify VAPID keys configuration

## Support

For technical support:
1. Check the browser console for errors
2. Verify admin backend connectivity
3. Review network requests in DevTools
4. Contact your system administrator

## Security

- All data encrypted in transit (HTTPS)
- Secure session management
- CSRF protection via Remix
- Content Security Policy headers
- Secure cookie configuration
