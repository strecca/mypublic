#!/bin/bash
echo "🔧 User PWA Development Setup"
echo "============================"

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 18+"
    exit 1
fi

echo "✅ Node.js version: $(node -v)"

# Install dependencies
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
fi

# Check for admin backend
echo "🔍 Checking admin backend connectivity..."
if curl -s http://localhost:3000/ > /dev/null 2>&1; then
    echo "✅ Admin backend is running on port 3000"
else
    echo "⚠️  Admin backend not detected on port 3000"
    echo "   Make sure to start the admin backend first"
fi

echo ""
echo "🚀 Ready to start User PWA development!"
echo "   Run: npm run dev"
echo "   URL: http://localhost:3001"
