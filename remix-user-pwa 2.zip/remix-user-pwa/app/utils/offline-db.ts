import { openDB, DBSchema, IDBPDatabase } from 'idb';
import type { FormSchema, FormSubmission } from '~/types';

interface FormManagerDB extends DBSchema {
  forms: {
    key: string;
    value: FormSchema;
    indexes: { 'by-group': string[]; 'by-priority': string; 'by-date': Date };
  };
  submissions: {
    key: string;
    value: FormSubmission;
    indexes: { 'by-form': string; 'by-status': string; 'by-date': Date };
  };
  drafts: {
    key: string;
    value: FormSubmission;
    indexes: { 'by-form': string; 'by-date': Date };
  };
  sync_queue: {
    key: string;
    value: { id: string; type: string; data: any; timestamp: Date };
  };
}

let db: IDBPDatabase<FormManagerDB>;

export async function initDB(): Promise<IDBPDatabase<FormManagerDB>> {
  if (db) return db;
  
  db = await openDB<FormManagerDB>('FormManagerDB', 3, {
    upgrade(db, oldVersion, newVersion, transaction) {
      // Forms store
      if (!db.objectStoreNames.contains('forms')) {
        const formsStore = db.createObjectStore('forms', { keyPath: 'id' });
        formsStore.createIndex('by-group', 'assignedGroups', { multiEntry: true });
        formsStore.createIndex('by-priority', 'priority');
        formsStore.createIndex('by-date', 'updatedAt');
      }

      // Submissions store
      if (!db.objectStoreNames.contains('submissions')) {
        const submissionsStore = db.createObjectStore('submissions', { keyPath: 'id' });
        submissionsStore.createIndex('by-form', 'formId');
        submissionsStore.createIndex('by-status', 'status');
        submissionsStore.createIndex('by-date', 'updatedAt');
      }

      // Drafts store
      if (!db.objectStoreNames.contains('drafts')) {
        const draftsStore = db.createObjectStore('drafts', { keyPath: 'id' });
        draftsStore.createIndex('by-form', 'formId');
        draftsStore.createIndex('by-date', 'updatedAt');
      }

      // Sync queue store
      if (!db.objectStoreNames.contains('sync_queue')) {
        db.createObjectStore('sync_queue', { keyPath: 'id' });
      }
    },
  });

  return db;
}

// Form operations
export async function saveForms(forms: FormSchema[]): Promise<void> {
  const database = await initDB();
  const tx = database.transaction('forms', 'readwrite');
  await Promise.all(forms.map(form => tx.store.put(form)));
  await tx.done;
}

export async function getFormsForGroups(userGroups: string[]): Promise<FormSchema[]> {
  const database = await initDB();
  const forms: FormSchema[] = [];
  
  for (const group of userGroups) {
    const groupForms = await database.getAllFromIndex('forms', 'by-group', group);
    forms.push(...groupForms);
  }
  
  // Deduplicate and sort by priority and date
  const uniqueForms = Array.from(
    new Map(forms.map(form => [form.id, form])).values()
  );
  
  return uniqueForms.sort((a, b) => {
    const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
    const aPriority = priorityOrder[a.priority] || 0;
    const bPriority = priorityOrder[b.priority] || 0;
    
    if (aPriority !== bPriority) {
      return bPriority - aPriority; // Higher priority first
    }
    
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });
}

// Submission operations
export async function saveSubmission(submission: FormSubmission): Promise<void> {
  const database = await initDB();
  await database.put('submissions', submission);
}

export async function getRecentSubmissions(limit: number = 20): Promise<FormSubmission[]> {
  const database = await initDB();
  const submissions = await database.getAllFromIndex('submissions', 'by-date');
  return submissions.reverse().slice(0, limit);
}

export async function getSubmissionsByForm(formId: string): Promise<FormSubmission[]> {
  const database = await initDB();
  return database.getAllFromIndex('submissions', 'by-form', formId);
}

// Draft operations
export async function saveDraft(draft: FormSubmission): Promise<void> {
  const database = await initDB();
  await database.put('drafts', draft);
}

export async function getDraft(formId: string): Promise<FormSubmission | undefined> {
  const database = await initDB();
  const drafts = await database.getAllFromIndex('drafts', 'by-form', formId);
  return drafts[0]; // Return most recent draft
}

export async function deleteDraft(draftId: string): Promise<void> {
  const database = await initDB();
  await database.delete('drafts', draftId);
}

// Sync queue operations
export async function addToSyncQueue(type: string, data: any): Promise<void> {
  const database = await initDB();
  const queueItem = {
    id: `${type}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    type,
    data,
    timestamp: new Date()
  };
  await database.put('sync_queue', queueItem);
}

export async function getSyncQueue(): Promise<any[]> {
  const database = await initDB();
  return database.getAll('sync_queue');
}

export async function clearSyncQueue(): Promise<void> {
  const database = await initDB();
  await database.clear('sync_queue');
}

// Cleanup old data
export async function cleanupOldData(): Promise<void> {
  const database = await initDB();
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  
  // Clean old drafts
  const drafts = await database.getAll('drafts');
  const oldDrafts = drafts.filter(draft => new Date(draft.updatedAt) < thirtyDaysAgo);
  
  const tx = database.transaction('drafts', 'readwrite');
  await Promise.all(oldDrafts.map(draft => tx.store.delete(draft.id)));
  await tx.done;
}
