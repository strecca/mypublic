import { Link } from 'react-router';
import { Calendar, Clock, AlertTriangle, FileText, Users } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import type { FormSchema } from '~/types';

interface FormCardProps {
  form: FormSchema;
}

export function FormCard({ form }: FormCardProps) {
  const getPriorityStyles = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'form-card-urgent border-red-500';
      case 'high':
        return 'form-card-high border-orange-500';
      case 'medium':
        return 'form-card-medium border-blue-500';
      case 'low':
        return 'form-card-low border-green-500';
      default:
        return 'form-card';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'high':
        return <Clock className="w-4 h-4 text-orange-500" />;
      default:
        return <FileText className="w-4 h-4 text-blue-500" />;
    }
  };

  const getPriorityBadge = (priority: string) => {
    const styles = {
      urgent: 'bg-red-100 text-red-800 border-red-200',
      high: 'bg-orange-100 text-orange-800 border-orange-200',
      medium: 'bg-blue-100 text-blue-800 border-blue-200',
      low: 'bg-green-100 text-green-800 border-green-200',
    };

    return (
      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${styles[priority as keyof typeof styles] || styles.medium}`}>
        {getPriorityIcon(priority)}
        <span className="ml-1 capitalize">{priority}</span>
      </span>
    );
  };

  const isOverdue = form.dueDate && new Date(form.dueDate) < new Date();
  const isDueSoon = form.dueDate && new Date(form.dueDate) < new Date(Date.now() + 24 * 60 * 60 * 1000);

  return (
    <Link
      to={`/dashboard/forms/${form.id}`}
      className={`block ${getPriorityStyles(form.priority)} hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200`}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 mb-1">
            {form.name}
          </h3>
          <p className="text-sm text-gray-600 line-clamp-2">
            {form.description}
          </p>
        </div>
        {getPriorityBadge(form.priority)}
      </div>

      {/* Due date warning */}
      {form.dueDate && (
        <div className={`mb-4 p-3 rounded-lg ${
          isOverdue 
            ? 'bg-red-50 border border-red-200' 
            : isDueSoon 
            ? 'bg-yellow-50 border border-yellow-200'
            : 'bg-gray-50 border border-gray-200'
        }`}>
          <div className="flex items-center">
            <Calendar className={`w-4 h-4 mr-2 ${
              isOverdue 
                ? 'text-red-500' 
                : isDueSoon 
                ? 'text-yellow-500'
                : 'text-gray-500'
            }`} />
            <span className={`text-sm font-medium ${
              isOverdue 
                ? 'text-red-700' 
                : isDueSoon 
                ? 'text-yellow-700'
                : 'text-gray-700'
            }`}>
              {isOverdue 
                ? 'Overdue' 
                : isDueSoon 
                ? 'Due today'
                : `Due ${formatDistanceToNow(new Date(form.dueDate), { addSuffix: true })}`
              }
            </span>
          </div>
        </div>
      )}

      {/* Form metadata */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center">
            <Users className="w-4 h-4 mr-1" />
            <span>{form.assignedGroups.join(', ')}</span>
          </div>
          <span>v{form.version}</span>
        </div>

        <div className="flex items-center text-sm text-gray-500">
          <Clock className="w-4 h-4 mr-1" />
          <span>Updated {formatDistanceToNow(new Date(form.updatedAt), { addSuffix: true })}</span>
        </div>
      </div>

      {/* Action indicator */}
      <div className="mt-4 pt-4 border-t border-gray-200">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-blue-600">
            Click to complete →
          </span>
          {form.settings.maxSubmissions && (
            <span className="text-xs text-gray-500">
              Max: {form.settings.maxSubmissions} submissions
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
