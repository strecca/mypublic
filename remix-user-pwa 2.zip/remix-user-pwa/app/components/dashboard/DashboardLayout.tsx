import { Link, useLocation, Form } from 'react-router';
import { useState } from 'react';
import { 
  FileText, 
  Clock, 
  CheckCircle, 
  Settings, 
  LogOut, 
  Menu, 
  X,
  Wifi,
  WifiOff,
  RotateCcw
} from 'lucide-react';
import type { User } from '~/types';
import { useSyncStatus } from './SyncStatusProvider';

interface DashboardLayoutProps {
  user: User;
  children: React.ReactNode;
}

export function DashboardLayout({ user, children }: DashboardLayoutProps) {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { isOnline, syncInProgress, pendingSubmissions, lastSync } = useSyncStatus();

  const navigation = [
    { name: 'Active Forms', href: '/dashboard/forms', icon: FileText, count: 3 },
    { name: 'Drafts', href: '/dashboard/drafts', icon: Clock, count: 1 },
    { name: 'Completed', href: '/dashboard/completed', icon: CheckCircle, count: 12 },
    { name: 'Settings', href: '/dashboard/settings', icon: Settings },
  ];

  const isActive = (href: string) => location.pathname === href;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-gray-600 bg-opacity-75 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200">
            <h1 className="text-xl font-bold text-gray-900">FormApp</h1>
            <button
              onClick={() => setSidebarOpen(false)}
              className="p-2 rounded-md text-gray-400 hover:text-gray-600 lg:hidden"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* User info */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-medium">
                  {user.name.charAt(0).toUpperCase()}
                </span>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">{user.name}</p>
                <p className="text-xs text-gray-500">{user.groups[0]}</p>
              </div>
            </div>
          </div>

          {/* Sync status */}
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                {isOnline ? (
                  <Wifi className="w-4 h-4 text-green-500 mr-2" />
                ) : (
                  <WifiOff className="w-4 h-4 text-red-500 mr-2" />
                )}
                <span className="text-sm text-gray-600">
                  {isOnline ? 'Online' : 'Offline'}
                </span>
              </div>
              
              {syncInProgress && (
                <RotateCcw className="w-4 h-4 text-blue-500 animate-spin" />
              )}
            </div>
            
            {pendingSubmissions > 0 && (
              <p className="text-xs text-orange-600 mt-1">
                {pendingSubmissions} pending sync
              </p>
            )}
            
            {lastSync && (
              <p className="text-xs text-gray-500 mt-1">
                Last sync: {new Date(lastSync).toLocaleTimeString()}
              </p>
            )}
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-6 space-y-2">
            {navigation.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.href);
              
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => setSidebarOpen(false)}
                  className={`flex items-center justify-between px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                    active
                      ? 'bg-blue-100 text-blue-700 border-r-2 border-blue-500'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center">
                    <Icon className="w-5 h-5 mr-3" />
                    {item.name}
                  </div>
                  {item.count !== undefined && (
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      active 
                        ? 'bg-blue-200 text-blue-800' 
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {item.count}
                    </span>
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Logout */}
          <div className="p-4 border-t border-gray-200">
            <Form action="/logout" method="post">
              <button
                type="submit"
                className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4 mr-3" />
                Sign Out
              </button>
            </Form>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Top bar */}
        <div className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 py-4 safe-area-inset-top">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(true)}
              className="p-2 rounded-md text-gray-400 hover:text-gray-600 lg:hidden"
            >
              <Menu className="w-6 h-6" />
            </button>
            
            <div className="flex items-center space-x-4">
              {/* Sync indicator */}
              <div className="flex items-center">
                {syncInProgress ? (
                  <div className="flex items-center text-blue-600">
                    <RotateCcw className="w-4 h-4 animate-spin mr-1" />
                    <span className="text-sm">Syncing...</span>
                  </div>
                ) : isOnline ? (
                  <div className="flex items-center text-green-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <span className="text-sm">Connected</span>
                  </div>
                ) : (
                  <div className="flex items-center text-orange-600">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-2"></div>
                    <span className="text-sm">Offline</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <main className="p-6 safe-area-inset">
          {children}
        </main>
      </div>
    </div>
  );
}
