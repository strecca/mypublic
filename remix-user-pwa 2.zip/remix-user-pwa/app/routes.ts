import { type RouteConfig, index, route } from "@react-router/dev/routes";

export default [
  // Main PWA route
  index("routes/_index.tsx"),
  
  // Future routes can be added here:
  // route("forms/:id", "routes/forms.$id.tsx"),
  // route("dashboard", "routes/dashboard.tsx"),
  
] satisfies RouteConfig;
